/* Mert Müldür - stylized pixel football character
   Canvas 2D helper. Usage: MertMuldurCharacter.draw(ctx, x, y, scale, time)
   This is an illustrative game sprite, not an official likeness. */
(function (root) {
  const api = {
    draw(ctx, x, y, scale = 1, time = 0) {
      if (!ctx) return;
      const s = scale, bob = Math.sin(time * 8) * 1.5 * s;
      ctx.save(); ctx.translate(x, y + bob); ctx.scale(s, s);
      const rect = (c, a,b,w,h) => { ctx.fillStyle=c; ctx.fillRect(a,b,w,h); };
      // shadow
      ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(0,1,13,4,0,0,Math.PI*2); ctx.fill();
      // legs and boots
      rect('#d9a477',-7,-22,5,13); rect('#d9a477',2,-22,5,13);
      rect('#17243a',-8,-11,7,4); rect('#17243a',2,-11,7,4);
      rect('#f4f0e8',-10,-8,9,3); rect('#f4f0e8',2,-8,9,3);
      // shorts
      rect('#172b4d',-9,-36,18,15); rect('#f4f0e8',-2,-35,4,3);
      // shirt
      rect('#f2c928',-10,-55,20,20); rect('#e5b91e',-10,-55,4,20); rect('#e5b91e',6,-55,4,20);
      rect('#172b4d',-3,-54,6,4); rect('#ffffff',-2,-47,4,7);
      // arms
      rect('#d9a477',-14,-51,4,15); rect('#d9a477',10,-51,4,15);
      rect('#f2c928',-14,-54,4,8); rect('#f2c928',10,-54,4,8);
      // neck and head
      rect('#bd875f',-3,-60,6,6); rect('#d9a477',-7,-73,14,14);
      rect('#30251f',-7,-75,14,6); rect('#30251f',-8,-71,3,7); rect('#30251f',4,-71,4,5);
      rect('#241b18',-4,-67,2,2); rect('#241b18',3,-67,2,2); rect('#8f5545',-2,-62,4,1);
      ctx.restore();
    }
  };
  root.MertMuldurCharacter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
